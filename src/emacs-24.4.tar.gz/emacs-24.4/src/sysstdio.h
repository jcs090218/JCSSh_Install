#include <stdio.h>
extern FILE *emacs_fopen (char const *, char const *);
